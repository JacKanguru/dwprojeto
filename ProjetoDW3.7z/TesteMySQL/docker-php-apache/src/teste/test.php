<?php
echo "Hello World <br />";
$counter = rand();
echo $counter;
?>