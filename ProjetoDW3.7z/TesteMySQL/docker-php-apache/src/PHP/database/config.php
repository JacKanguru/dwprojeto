<?php

const DB = 'mysql';
const DBHOST = 'db';
const DBNAME = 'computer';
const DBUSER = 'root';
const DBPWD = 'abc123';
