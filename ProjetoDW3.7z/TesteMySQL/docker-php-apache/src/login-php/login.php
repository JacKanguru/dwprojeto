<?php 

  session_start();

  include('conexao.php');

  $login = $_POST['user'];
  $entrar = $_POST['entrar'];
  $senha = MD5($_POST['pass']);

    if (isset($entrar)) {
             
      try{
        $sql = "SELECT * FROM usuarios WHERE login = '$login'";
        $stmt = $PDO->prepare($sql);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_OBJ);
        $musr = $data->login;
        $mpass = $data->senha;
      }catch(Exception $erro){
          echo $erro;
      }

      if( $login == $musr AND $senha == $mpass){
        //pagina caso o login seja bem sucedido
        header("Location:paginax.php");
        exit();  
      }else{
		//pagina de erro de login
        header("Location:paginay.php");
        exit();
      }
      
    }
    
?>